import logo from './logo.svg';
import './App.css';


import Data from './Components/Data';



import { Grid } from '@mui/material';
import Home from "./Components/Home"


import Read from "./Components/Read"
import WriteAndRead from "./Components/WriteAndRead"
import Baisc from "./Components/Baisc"

function App() {

  return (
    <> 
    <WriteAndRead />
    {/* <Read /> */}
    {/* <Home /> */}
    {/* <Data /> */}
    {/* <Baisc /> */}

    </>
  );
}

export default App;
